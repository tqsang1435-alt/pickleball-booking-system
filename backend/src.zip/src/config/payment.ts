export const paymentConfig = {};
