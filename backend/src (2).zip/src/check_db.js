require('dotenv').config({ path: '.env.local' });
const sql = require('mssql');

const databaseConfig = {
  user: process.env.DB_USER || "sa",
  password: process.env.DB_PASSWORD || "",
  server: process.env.DB_SERVER || "localhost",
  database: process.env.DB_DATABASE || "PCS_System",
  port: Number(process.env.DB_PORT || 1433),
  options: {
    encrypt: false,
    trustServerCertificate: true,
  },
};

async function run() {
  try {
    console.log("Connecting to SQL Server...");
    const pool = await sql.connect(databaseConfig);
    console.log("Connected. Checking Promotions table count...");
    
    const checkResult = await pool.request().query("SELECT COUNT(*) AS cnt FROM Promotions");
    const count = checkResult.recordset[0].cnt;
    console.log(`Current Promotions count: ${count}`);

    if (count === 0) {
      console.log("Inserting sample promotions...");
      await pool.request().query(`
        INSERT INTO Promotions 
        (PromotionCode, PromotionName, DiscountType, DiscountValue, MaxDiscountAmount, MinOrderAmount, UsageLimit, UsedCount, StartDate, EndDate, Status)
        VALUES
        ('CHAOHE2026', N'Chào Hè Rực Rỡ', 'Percent', 10.00, 50000.00, 100000.00, 100, 0, '2026-05-01', '2026-08-31', 'Active'),
        ('WELCOME50', N'Chào Mừng Thành Viên Mới', 'Fixed', 50000.00, 50000.00, 200000.00, 500, 0, '2026-01-01', '2026-12-31', 'Active'),
        ('FREESHIP', N'Ưu Đãi Đặc Biệt', 'Fixed', 20000.00, 20000.00, 0.00, NULL, 0, '2026-01-01', '2026-12-31', 'Active')
      `);
      console.log("Sample promotions inserted successfully!");
    }

    const finalResult = await pool.request().query("SELECT * FROM Promotions");
    console.log("Current Promotions in database:", finalResult.recordset);
  } catch (error) {
    console.error("Error:", error);
  } finally {
    process.exit(0);
  }
}

run();
