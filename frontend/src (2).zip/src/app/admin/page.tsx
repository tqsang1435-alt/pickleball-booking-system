import styles from "./AdminDashboard.module.css";

export default function AdminDashboardPage() {
  return (
    <main className={styles.page}>
      <div className={styles.header}>
        <div>
          <p>Xin chào, Admin 👋</p>
          <h1>Tổng quan quản trị hệ thống</h1>
        </div>

        <button className={styles.dateBtn}>28/05/2025</button>
      </div>

      <section className={styles.stats}>
        <div className={styles.statCard}>
          <span>💰</span>
          <p>Tổng doanh thu</p>
          <h2>45.250.000 đ</h2>
          <small>↑ 12.5% so với hôm qua</small>
        </div>

        <div className={styles.statCard}>
          <span>📅</span>
          <p>Tổng đơn đặt sân</p>
          <h2>128</h2>
          <small>↑ 8.3% so với hôm qua</small>
        </div>

        <div className={styles.statCard}>
          <span>🎾</span>
          <p>Sân đang hoạt động</p>
          <h2>6</h2>
          <small>100% tổng số sân</small>
        </div>

        <div className={styles.statCard}>
          <span>👥</span>
          <p>Người chơi mới</p>
          <h2>32</h2>
          <small>↑ 15.6% so với hôm qua</small>
        </div>
      </section>

      <section className={styles.grid}>
        <div className={styles.cardLarge}>
          <div className={styles.cardHeader}>
            <h2>Lịch đặt sân hôm nay</h2>
            <select>
              <option>Tất cả sân</option>
            </select>
          </div>

          <div className={styles.schedule}>
            {["Sunrise Court", "Ocean Court", "Golden Smash", "Skyline Court", "Victory Court"].map(
              (court, index) => (
                <div className={styles.scheduleRow} key={court}>
                  <strong>{court}</strong>
                  <div className={styles.timeline}>
                    <span></span>
                    <span className={index % 2 === 0 ? styles.booked : ""}></span>
                    <span></span>
                    <span className={styles.booked}></span>
                    <span></span>
                    <span className={index % 2 === 1 ? styles.booked : ""}></span>
                  </div>
                </div>
              )
            )}
          </div>

          <button className={styles.centerBtn}>Xem lịch đặt sân chi tiết →</button>
        </div>

        <div className={styles.sideCard}>
          <h2>Doanh thu</h2>
          <h1>45.250.000 đ</h1>
          <p className={styles.green}>↑ 12.5% so với 7 ngày trước</p>

          <div className={styles.chart}>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
          </div>
        </div>

        <div className={styles.cardLarge}>
          <h2>Đơn đặt sân mới nhất</h2>

          <table>
            <thead>
              <tr>
                <th>Mã đơn</th>
                <th>Khách hàng</th>
                <th>Sân</th>
                <th>Thời gian</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
              </tr>
            </thead>

            <tbody>
              {[
                ["#ORD-1287", "Nguyễn Tuấn Anh", "Sunrise Court", "10:00", "350.000 đ", "Đã xác nhận"],
                ["#ORD-1286", "Lê Thanh Tùng", "Ocean Court", "14:00", "600.000 đ", "Chờ xác nhận"],
                ["#ORD-1285", "Phạm Minh Tuấn", "Golden Smash", "18:00", "400.000 đ", "Đã thanh toán"],
              ].map((row) => (
                <tr key={row[0]}>
                  {row.map((item) => (
                    <td key={item}>{item}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className={styles.sideCard}>
          <h2>Sân được đặt nhiều</h2>

          {["Sunrise Court", "Ocean Court", "Golden Smash", "Skyline Court"].map(
            (item, index) => (
              <div className={styles.rank} key={item}>
                <span>{index + 1}</span>
                <p>{item}</p>
                <strong>{128 - index * 17} lượt</strong>
              </div>
            )
          )}
        </div>
      </section>
    </main>
  );
}