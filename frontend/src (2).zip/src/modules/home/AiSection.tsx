import Link from "next/link";
import styles from "./HomePage.module.css";

export default function AiSection() {
  return (
    <section className={styles.aiSection}>
      <div className={styles.aiPanel}>
        <div className={styles.aiContent}>
          <span>AI ASSISTANT</span>

          <h2>
            Trợ lý AI hỗ trợ
            <br />
            trải nghiệm Pickleball
          </h2>

          <p>
            AI phân tích nhu cầu và lịch sử hoạt động để
            đề xuất sân, Coach và người chơi phù hợp.
          </p>

          <Link href="/ai">
            Khám phá AI →
          </Link>
        </div>

        <div className={styles.aiCards}>
          <div className={styles.aiCard}>
            <div>👨‍🏫</div>
            <h3>Gợi ý Coach</h3>
            <p>Đề xuất Coach theo trình độ và mục tiêu.</p>
          </div>

          <div className={styles.aiCard}>
            <div>🎾</div>
            <h3>Gợi ý sân</h3>
            <p>Tìm sân phù hợp theo vị trí và thời gian.</p>
          </div>

          <div className={styles.aiCard}>
            <div>👥</div>
            <h3>Tìm người chơi</h3>
            <p>Kết nối với người chơi có trình độ tương đồng.</p>
          </div>
        </div>
      </div>
    </section>
  );
}